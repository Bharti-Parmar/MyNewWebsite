<!doctype html>
<html lang="en">
	<head>
		<title> Wokfo</title>
		<meta charset="utf-8">

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- bootstrap 4 libraby -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/nav.css">
		<!-- font wesome library for icon -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<!-- bootstrap 4 JS and JQuery libraries -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

        <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
		<!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
		<!-- <link rel="stylesheet" href="css/font-awesome.min.css"> -->
		<link rel="stylesheet" type="text/css" href="css/extra-style.css">
		<link rel="stylesheet" type="text/css" href="css/nav.css">
		<link rel="stylesheet" type="text/css" href="css/who_we_are.css">
		<link rel="stylesheet" type="text/css" href="css/our_service.css">
		<link rel="stylesheet" type="text/css" href="css/gallery.css">


    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- <script src="js/bootstrap.min.js"></script> -->


	</head>
	<body id="home">
	<!-- <div class="container-fluid" style="background-color:#d3edf8;">  -->
