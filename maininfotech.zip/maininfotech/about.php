

<div class="container-fluid who" id="who_we_are">
<h1 style="text-align: center; ">
  <!-- <u style="color:black"><b>Welcome to Dental Clinic & Implant Center</b></u></h1> -->
  <div class="row">
    <div class="col-lg-6 col-sm-6 col-xs-12">

    </div>

    <div class="col-lg-6 col-sm-6 col-xs-12">

    </div>
  </div>
</div>
