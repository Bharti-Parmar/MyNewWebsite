
<div class="container-fluid" id="testimonial" style="background-color:#f2f2f2;">
  <h1 style="color:black;text-align: center;margin-top: 80px;"><u><b>Testimonials</b></u></h1>
  <div class="row">
    <div class="col-lg-4 col-sm-4 col-xs-12"></div>
    <div class="col-lg-4 col-sm-4 col-xs-12"></div>
    <div class="col-lg-4 col-sm-4 col-xs-12"></div>
  </div>
</div>
