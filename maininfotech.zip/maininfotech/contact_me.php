<!--<canvas id="myCanvas" width="1320" height="140" style="border:1px solid #b37700;">+91-9876543210</canvas>
<script src="js/canvas.js"></script>-->

	<div class="container-fluid" style=" padding:10px;background-color:#b37700;">
		<div class="div1" style="background-color:#e68a00;padding:10px;">
			<div class="div2" style="padding:10px;">
						<center>
							<img src="image\a.png" height="50px;" width="50px">
							<p style="font-weight:bold;font-size: 20px;color:black"><i>Have any questions? Call Now - +91-9876543210</i></p>
						</center>
			</div>
		</div>
	</div>
