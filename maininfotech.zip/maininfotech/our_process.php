
<div class="container-fluid bg-3 text-center" id="why_us" style="margin-top: 80px;margin-bottom: 80px;">
  <!-- <h1 style="text-align:center; color:black;"><u><b> Why Us </b></u></h1> -->

  <div class="row">
      <div class="col-md-2 col-xs-12" style="margin-top:25px;">
      </div>

      <div class="col-md-8 col-xs-12" style="margin-top:25px;text-align:justify;color:#b37700;font-size: 20px;">
      </div>

      <div class="col-md-2 col-xs-12" style="margin-top:25px;">
      </div>
  </div>

<div class="row" style="margin-top: 40px;margin-left: 20px;margin-right: 20px;">
    <div class="col-md-4 col-xs-12">
            <div class="panel-body">
            </div>
    </div>
    <div class="col-md-4 col-xs-12">
            <div class="panel-body">
            </div>
    </div>
    <div class="col-md-4 col-xs-12">
            <div class="panel-body" >
          </div>
    </div>
  </div>


</div>


<div class="container-fluid">

</div>
