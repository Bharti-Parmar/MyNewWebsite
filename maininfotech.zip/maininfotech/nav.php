<style>
	a{
		font-family: roboto;
    font-weight: 600;
    letter-spacing: 1px;
    font-size: 14px;
	}
</style>

<nav class="navbar navbar-expand-md navbar-lg-light navbar-sm-dark sticky-top bg-dark">
	<div class="container-fluid">
			<div class="col-lg-2 col-sm-2 col-xs-12">
				<a href="#home" class="navbar-brand">W0kfo</a>
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
					<span class="navbar-toggler-icon"></span>
				</button>
			</div>
			<div class="col-lg-10 col-sm-10 col-xs-12">
				<div class="collapse navbar-collapse justify-content-between float-lg-right" id="navbarCollapse">
					<div class="navbar-nav">
							<a href="#home" class="nav-item nav-link active ml-xl-2">Home</a>
							<a href="#about" class="nav-item nav-link ml-xl-2">About Us</a>
							<div class="nav-item dropdown ml-xl-2">
									<a href="#service" class="nav-link dropdown-toggle" data-toggle="dropdown">Our Services</a>
									<div class="dropdown-menu">
											<a href="#training" class="dropdown-item">Training And Placement</a>
											<a href="#it" class="dropdown-item">IT Solution</a>
											<a href="#business" class="dropdown-item">Business Solution</a>
									</div>
							</div>
							<a href="#usp" class="nav-item nav-link ml-xl-2">Our USP</a>
							<a href="#testimonial" class="nav-item nav-link ml-xl-2">Testimonial</a>
							<div class="nav-item dropdown ml-xl-2">
								<a href="#login" class="nav-link dropdown-toggle" data-toggle="dropdown">Login</a>
									<div class="dropdown-menu">
											<a href="#login" class="dropdown-item">Admin Login</a>
											<a href="#employee" class="dropdown-item">Employee Login</a>
											<a href="#seller" class="dropdown-item">Supplier / Seller Login</a>
											<a href="#customer" class="dropdown-item">Customer / Buyers Login</a>
											<a href="#other" class="dropdown-item">Other Login</a>
									</div>
							</div>
							<a href="#register" class="nav-item nav-link btn btn-dark text-white ml-5">Register</a>
					</div>
				</div>
			</div>
	</div>
</nav>
					        <!-- <li class="dropdown">
					          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Our Services
					            <span class="caret"></span>
					          </a>
					          <ul class="dropdown-menu">
					            <li><a href="#service">Dental Services</a></li>
					            <li><a href="#service">Dental Cleaning</a></li>
					            <li><a href="#service">Dental Implants</a></li>
					          </ul>
					        </li> -->
