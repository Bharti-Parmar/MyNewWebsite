<?php
  include('header1.php');
?>

<!-- booking successfull -->
<!-- <?php
     if(@$_GET["save"]) { ?>

	<div class="alert alert-success alert-dismissible">
   <a href="index.php" class="close">&times;</a>
 	 <strong>Success!</strong> Indicates a successful or positive action.
 	</div>
 <?php  }
       ?>

<?php
     if(@$_GET["comment"]) { ?>


	<div class=" alert alert-success alert-dismissible">
   <a href="index.php" class="close">&times;</a>
 	 <strong>Success!</strong> Your Comment Successfully Submitted.
 	</div>

 <?php  }
       ?> -->

					<!-- navigation bar -->

<?php
    include('nav.php');
?>
						<!-- carousel image -->

<?php
    include('carousel.php');
?>

						<!--- who we are -->
<?php
     include('about.php');
?>
						<!--- Testimonial -->
<?php
     include('our_process.php');
?>

						<!-- contact number -->
<?php
     include('our_service.php');
?>

						<!--- Our service -->
<?php
     include('usp.php');
?>


						<!--- Gallery -->
<?php
     include('testimonial.php');
?>

						<!--- Contact info -->
<?php
     include('contact_me.php');
?>

<?php
  include('footer1.php');
?>
